<?php

    $action     = "<a href=''><span class='text-danger'><i class='far fa-lg fa-trash-alt'></i></span></a> &nbsp;&nbsp;&nbsp; " ;
    $data       = array(
        array("Soni","Mobile Legend","Game",$action),
        array("Isgi","Futsal","Olahraga",$action),
        array("Iqbal","Basket","Olahraga",$action),
        array("Kiky","PUBG","Game",$action)
    );
    $data_hobby = array("Mobile Legend","PUBG","Free Fire","Futsal","Basket","Badminton");
    $data_category = array("Game","Olahraga");
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="font/css/all.min.css" />
    <link rel="stylesheet" href="font/css/fontawesome.min.css" />
    <link href="font/css/fontawesome.css" rel="stylesheet">
    <link href="font/css/brands.css" rel="stylesheet">
    <link href=" font/css/solid.css" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <title>Hello, world!</title>
  </head>
  <body >
    <nav class="navbar navbar-expand-lg navbar-light shadow p-3 mb-5 bg-white rounded">
        <a class="navbar-brand" href="#"><img src="img/arkademy_logo.png" width="150px" class="d-inline-block align-top" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php"><h4>ARKADEMY BOOTCAMP</h4> <span class="sr-only">(current)</span></a>
                </li>
            </ul>
  </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-11">
        </div>
        <div class="col-1">
        <button type="submit" class="btn btn-warning text-light mb-3 shadow px-4 rounded" data-toggle="modal" data-target="#modalInsert">ADD</button>
        </div>
        <!--Modal-->
        <div class="modal fade" id="modalInsert" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalInsertLabel">ADD DATA</h5>
                        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Name ..">
                        </div>
                        <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect1">
                                    <?php
                                        $jml_arr = count($data_hobby);
                                        for ($i=-1; $i <= $jml_arr-1 ; $i++) { 
                                            if ($i == -1) {
                                                echo "<option value=''>Hobby ..</option>";
                                            }
                                            else{
                                                echo "<option value='".$data_hobby[$i]."'>".$data_hobby[$i]."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                        </div>
                        <div class="form-group">
                                <select class="form-control" id="exampleFormControlSelect1">
                                    <?php
                                        $jml_arr = count($data_category);
                                        for ($i=-1; $i <= $jml_arr-1 ; $i++) { 
                                            if ($i == -1) {
                                                echo "<option value=''>Category ..</option>";
                                            }
                                            else{
                                                echo "<option value='".$data_category[$i]."'>".$data_category[$i]."</option>";
                                            }
                                        }
                                    ?>
                                </select>
                        </div>
                    </form>
                </div>
                
                <div class="modal-footer">
                <button type="submit" class="btn btn-warning text-light mb-3 shadow px-4 rounded">ADD</button>
                </div>
            </div>
        </div>
        <!--Modal-edit-->
       



        
        
    </div>
   
        <table class="table table-bordered text-center">
            <thead>
                <tr>
                <th scope="col">Name</th>
                <th scope="col">Hobby</th>
                <th scope="col">Category</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php  
                    $jml_arr = count($data);

                    for ($i=0; $i <= $jml_arr-1 ; $i++) { 
                        echo "<tr>
                            <td scope='col'>".$data[$i][0]."</td>
                            <td scope='col'>".$data[$i][1]."</td>
                            <td scope='col'>".$data[$i][2]."</td>
                            <td scope='col'>".$data[$i][3]." <a href='' data-toggle='modal' data-target='#modalEdit".$i."'   ><span><i class='far fa-lg fa-edit'></i></span></a></td>
                        </tr>";
                        echo'<div class="modal fade" id="modalEdit'.$i.'" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalEditLabel">EDIT DATA</h5>
                        <button type="button" class="close text-danger" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="'.$data[$i][0].'">
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="'. $data[$i][1].'">   
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="'. $data[$i][2].'">   
                        </div>
                    </form>
                </div>
                
                <div class="modal-footer">
                <button type="submit" class="btn btn-warning text-light mb-3 shadow px-4 rounded">EDIT</button>
                </div>
            </div>
        </div>';         
                        
                    }

                ?>
               
               
            </tbody>
        </table>
    </div>
</div>
        


                  

            
            
       
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>