<?php
    include("koneksi.php");

    
    $query = mysqli_query($conn,"SELECT nama.name, hobi.hobby, kategori.category FROM ( ( nama INNER JOIN hobi ON nama.id_hobby = hobi.id ) INNER JOIN kategori ON nama.id_category = kategori.id ))");
    $result = mysqli_fetch_assoc($query)
    
?>