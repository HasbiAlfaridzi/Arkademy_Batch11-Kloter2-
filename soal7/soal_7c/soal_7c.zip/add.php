<?php 
include 'koneksi.php';
$nama = $_POST['name'];
$hobby = $_POST['hobby'];
$category = $_POST['category'];


 
mysqli_query($conn,"INSERT INTO nama (name,id_hobby,id_category) VALUES ('$nama','$hobby','$category')");

header("location:result.php?id=1");

?>