<?php 
include 'koneksi.php';
$nama = $_POST['name'];
$hobby = $_POST['hobby'];
$category = $_POST['category'];

mysqli_query($conn,"UPDATE nama SET  id_hobby = $hobby, id_category = $category WHERE nama.id = $nama" );

echo "<script>alert('Data telah diubah');</script>";

header("location:result.php?id=2");

?>