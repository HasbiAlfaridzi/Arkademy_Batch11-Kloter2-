<?php 
include 'koneksi.php';
$id = $_GET['id'];
 
 
// menghapus data dari database
mysqli_query($conn,"DELETE FROM nama WHERE name='$id'");
 
// // mengalihkan halaman kembali ke index.php
header("location:result.php?id=3");
 
?>